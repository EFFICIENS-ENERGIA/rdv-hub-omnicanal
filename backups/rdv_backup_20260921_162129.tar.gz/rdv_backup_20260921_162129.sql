-- ============================================================================
-- 💾 RDV-HUB SAAS -- DUMP SQL DE SAUVEGARDE AUTOMATISÉE
-- Date de génération (UTC) : 2026-09-21 14:21:29
-- Nombre d'enregistrements : 3
-- ============================================================================

-- 1. Schéma des tables relationnelles
CREATE TABLE IF NOT EXISTS rdv_appointments (
    id VARCHAR(64) PRIMARY KEY,
    client_name VARCHAR(255) NOT NULL,
    email VARCHAR(255),
    phone VARCHAR(64),
    channel VARCHAR(32) NOT NULL DEFAULT 'web',
    subject VARCHAR(255) NOT NULL,
    address TEXT,
    date DATE NOT NULL,
    start_time VARCHAR(8) NOT NULL,
    end_time VARCHAR(8) NOT NULL,
    amount DECIMAL(12,2) NOT NULL DEFAULT 0.00,
    status VARCHAR(32) NOT NULL DEFAULT 'new',
    notes TEXT,
    lead_score INT DEFAULT 50,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS rdv_financial_snapshots (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    snapshot_date TIMESTAMP NOT NULL,
    total_appointments INT NOT NULL,
    ca_previsionnel DECIMAL(14,2) NOT NULL,
    ca_realise DECIMAL(14,2) NOT NULL,
    show_up_rate_percent DECIMAL(5,2) NOT NULL,
    average_ticket DECIMAL(12,2) NOT NULL
);

-- 2. Index de performance
CREATE INDEX IF NOT EXISTS idx_rdv_date ON rdv_appointments(date);
CREATE INDEX IF NOT EXISTS idx_rdv_status ON rdv_appointments(status);
CREATE INDEX IF NOT EXISTS idx_rdv_channel ON rdv_appointments(channel);

-- 3. Insertion des données sous bloc transactionnel
BEGIN TRANSACTION;

INSERT INTO rdv_appointments (id, client_name, email, phone, channel, subject, address, date, start_time, end_time, amount, status, notes, lead_score) VALUES ('rdv-1', 'Groupe Tertiaire Méditerranée', 'contact@tertiaire-med.fr', '+33 4 91 00 22 33', 'web', 'Réhabilitation Immeuble de Bureaux 3500m²', '25 Quai d''Arenc, 13002 Marseille', '2026-09-25', '09:30', '11:00', 280000.0, 'confirmed', 'Dossier d''appel d''offres privé. Consultation restreinte.', 96);
INSERT INTO rdv_appointments (id, client_name, email, phone, channel, subject, address, date, start_time, end_time, amount, status, notes, lead_score) VALUES ('rdv-2', 'SCI Les Oliviers', 'gestion@sci-oliviers.com', '+33 6 19 28 37 46', 'whatsapp', 'Construction 4 Villas Jumelées RT2020', '40 Route de Puyricard, 13100 Aix-en-Provence', '2026-09-26', '14:00', '15:30', 420000.0, 'new', 'Contact direct via WhatsApp. Terrain acquis à Aix-en-Provence.', 92);
INSERT INTO rdv_appointments (id, client_name, email, phone, channel, subject, address, date, start_time, end_time, amount, status, notes, lead_score) VALUES ('rdv-3', 'Cabinet Avocats & Associés', 'direction@avocats-associes.fr', '+33 1 45 67 89 00', 'email', 'Agencement Haut de Gamme & Isolation Phonique', '8 Place de la Concorde, 75008 Paris', '2026-09-28', '10:30', '11:30', 45000.0, 'pending', 'Email avec cahier des charges acoustique strict.', 84);

-- 4. Snapshot des métriques financières
INSERT INTO rdv_financial_snapshots (snapshot_date, total_appointments, ca_previsionnel, ca_realise, show_up_rate_percent, average_ticket) VALUES ('2026-09-21 14:21:29', 3, 745000.0, 0, 100.0, 248333.33);

COMMIT;
